# Project Link - Student Wellness & Council Portal

This is a static HTML application for the De La Salle University Dasmarinas Basic Education Department Student Wellness & Council Portal.

## Deployment Instructions

### For GitHub Pages:
1. Create a new GitHub repository.
2. Upload the `index.html` file to the repository root.
3. Go to Settings > Pages, select "Deploy from a branch", choose main branch, and save.
4. Your site will be available at `https://yourusername.github.io/repositoryname/`

### For InfinityFree:
1. Log in to your InfinityFree account.
2. Go to File Manager.
3. Upload the `index.html` file to the `htdocs` or `public_html` folder.
4. Your site will be available at your domain.

## Features
- User authentication (Student, Council, Admin)
- Announcements feed
- Concern reporting
- Event evaluations
- Chat with adviser
- Council member info
- Resources download
- Admin dashboard

## Backend
The app connects to a Google Sheets API via Apps Script for data persistence.

API URL: https://script.google.com/macros/s/AKfycbyrHuZPojrn-G09RQ_ZebsRe30I4RAmuPess0r8P5EEMbwnf9gGoMw0d0FWZQIISQJd/exec

## Default Users
- student01 / student123 (Student)
- council01 / council123 (Student Council)
- admin / admin123 (Administrator)